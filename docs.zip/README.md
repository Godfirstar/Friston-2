# Friston-3 · 罗德岛智能作业平台交互项目

**非官方《明日方舟》角色交互项目。** 对话采用原作 Friston-3 身份。当前实现本地 Ollama 对话、YuNet 人脸感知、普通摄影、自动构图摄影，以及 SQLite 离线人物知识与互动记忆。机械臂递物尚未接入。工程目录和 Python 包名仍保留 `Friston-2` / `friston2`，运行显示使用 Friston-3。

v0.5 将世界观资料源替换为 [littlepangding/arknights_lore_wiki](https://github.com/littlepangding/arknights_lore_wiki)，按“人物—关系—故事—出处”重新组织。人物关系采用可追溯的有向图，存储仍使用 SQLite，支持离线查询和 JSON 子图导出。

**该 Wiki 是 LLM 阅读剧情后生成的二次总结，作者明确提醒可能存在错误与幻觉。** 本项目保留这一来源属性；“资料明确写了”不等于“已核对游戏原文”。导入的数据不自动升级为已验证原作事实。

## 运行环境与启动

- Windows / Conda，沿用已有 `photorobot` 环境；Python 3.10+。
- 本地 Ollama，路由与对话共用 `qwen3.5:9b`（Q4_K_M），地址 `http://127.0.0.1:11434/api/chat`。本机已下载；其他机器先运行 `ollama pull qwen3.5:9b`。
- OpenCV、真实摄像头及 `models/face_detection_yunet_2023mar.onnx`。
- 知识导入和关系检索使用 SQLite；语义检索沿用现有 FastEmbed、`BAAI/bge-small-zh-v1.5` 和 `terra_semantic.npz`，没有新增向量库或重建知识库。

在项目根目录的 PowerShell 中运行：

```powershell
conda activate photorobot
python main.py
```

视觉预览入口为 `python preview.py`。如果当前知识库尚未按 v0.5 构建，先执行下方的构建命令。

## 数据来源与结构

当前源文件位于 `data/external/arknights_lore_wiki`。只读取已发布的 `data/char_v3/*.txt`、`data/stories/*.txt` 和 `data/char_alias.txt`；排除 `prompt_*` 生成提示词、旧版 `data/chars` 和 `docs` 展示副本。旧版人物目录可能包含已移除的重复人物或异格页面，因此不与新版自动合并。

| 内容 | 组织方式与用途 |
| --- | --- |
| 人物与别名 | 以来源 ID 识别人物，保留名称、别名及资料卡；别名存在歧义时不强行合并人物 |
| 人物栏目 | 保存简要介绍、详细介绍、相关角色、剧情高光等栏目及对应文本片段 |
| 人物关系 | 从“相关角色”栏目建立有向关联，保留对象标签、完整描述和原文位置 |
| 未解析对象 | 群体标签、歧义名称和未找到独立页面的对象保留为引用节点，便于后续核对 |
| 活动与故事 | 保存活动和干员密录总结；人物与故事之间的提及关联单独存储 |
| 来源记录 | 保存仓库版本、文件路径、内容哈希及文本位置，便于检查每条材料从哪里来 |

关系边的方向表示“这份人物资料谈到了谁”。例如 A 的“相关角色”栏目写到 B，就记录 `A → B` 及该条描述；不会把句子中的主语、宾语强行转换成“研发者”“上级”等关系。A 和 B 在同一个故事中被提及，也不会自动生成朋友、敌人或上下级关系。

详细设计、字段含义及后续扩展边界见 [知识图谱说明](docs/KNOWLEDGE_GRAPH.md)。

## 构建与查询

首次获取源数据时执行（当前工作目录已下载）：

```powershell
git clone --depth 1 https://github.com/littlepangding/arknights_lore_wiki.git data/external/arknights_lore_wiki
```

`data/external/` 与运行数据库不纳入项目 Git；在其他机器上需要获取源数据后重建。

退出 `main.py` 和打开知识库的 SQLite 查看器后，在项目根目录运行：

```powershell
python -m friston2.knowledge.terra_kb build --source data/external/arknights_lore_wiki
python -m friston2.knowledge.terra_kb stats
python -m friston2.knowledge.terra_kb card 可露希尔
python -m friston2.knowledge.terra_kb profile 多萝西
python -m friston2.knowledge.terra_kb relations 多萝西 --limit 12
python -m friston2.knowledge.terra_kb search 矿石病 --limit 3
python -m friston2.knowledge.terra_kb network 可露希尔 --depth 1 --limit 30 --output data/runtime/closure_graph.json
```

构建先写临时数据库，成功后再替换 `data/runtime/terra_lore.db`。构建不会清空 `data/runtime/npc_memory.db` 中的真实互动记忆。更新上游源文件后需显式重建；对话过程中不会自动联网下载、生成资料或重建全库。

旧 GameData 和 `data/retired_lore/` 目录现已不存在。此前的旧导入器缓存、示例导出与可选精简项目见 [清理清单](docs/CLEANUP_AUDIT_2026-10-19.md)。身份迁移后须重建知识库，移除旧 Friston-2 自创节点及项目关系。

`network` 导出围绕指定人物的局部关系图，可供后续图形界面使用。深度和数量限制用于控制图的大小；它不代表全库关系已经展示完整。故事文本中的生成时间是资料元数据，不能当作游戏内事件年代。

## 对话、设定与记忆

- Agentic RAG v2 默认开启：NPC 前置独立语义路由。使用同一个 FastEmbed 中文模型对 `data/knowledge/intent_examples.json` 中的 301 条意图例句编码（`CHAT / KNOWLEDGE / LIVE / FOLLOWUP`），仅当语义相似、类别间隔、近邻一致度均过阈值时直接路由；不确定、指代追问交给现有 Qwen3.5:9B 的上下文路由器。语义分类对象是**回答是否需要证据**，不是把查询与剧情段落做相似度比较。聊天只生成自然台词；事实检索保留原有实体消歧和引用边界。推理分数并非校准概率，未通过阈值不意味着某一类事实成立。
- RETRIEVE 先做数据库别名、人物栏目和有向关系检索，再按需使用已有的中文向量索引与全文检索。直接关系优先，不用共同出场或共享邻居推断朋友、亲属或上下级。关系条目保留原始对象标签、否定、时间、存疑状态及群体成员各自的行为。
- 介绍优先人物概览；能力、身份纠正、加入原因和指定活动问题使用对应栏目及故事原文。代词追问沿用当前人物，换人物则切换证据。别名歧义直接列出数据库候选，选择后按原问题重新检索；不使用人物问答白名单。
- CHAT 高置信语义路径只调用一次 Qwen 生成台词；语义不确定时先调用一次 Qwen 路由，若它选择 CHAT 则复用其回复。REUSE / RETRIEVE 的确认路径为零或一次语义阶段、零或一次 Qwen 路由，加至多一次原有回答生成或原文选择。LIVE 数据未接入时返回不编造状态的明确短答。直接原文和待澄清分支可能更少。事实问答由模型选择完整原文单元，服务端输出带来源的原句；身份属性和简短直接关系可直接读取数据库。双人关系保留双方档案的不同表述，避免模型重写方向、血缘、因果和否定。片段保留主语与后续纠正，不能为了缩短而截掉限定。评价、偏好和普通聊天继续自然生成。
- 当前基线已移除在线 Cross-Encoder 重排、同模型复审和多次重写，v2 保持该状态；独立重排实验 CLI 保留。追问可在路由的同一次调用中补全检索问题，不另加查询改写调用。外层 Agent / Planner / SkillManager 和设备技能不变；这里的调用数不包含可能发生的外层 Planner 调用或启动预热。
- 本地规则检查来源编号、实体、身份与实际设备边界，**不代表逐句事实认证**。模型失败时只引用相关的完整短证据；不拆走否定或转折，不从被拒绝的草稿继续生成。资料不足就明确说缺少依据，资料冲突要保留分歧。数据库仍是二次整理资料，未升级为游戏原文验证库。
- 普通聊天使用简短、温和的角色口吻，不把角色语气写成私人交情或实际行动。真实拍照、保存状态和现实会面只认执行记录；用户自述、历史台词与世界观资料不能证明设备已完成任务。
- 最多保留三轮同话题历史；历史用于衔接，不作为新事实。`查看证据`可检查实际输入、来源、最终引用编号、草稿、回退原因、模型耗时与输出路径，诊断保存在当前会话中。
- `记住：内容`保存明确的用户自述；`忘记：关键词`删除匹配的用户记录与对话日志。`清空记忆`仅清当前话题；`清空长期记忆`清除保存的互动记录。重启不把旧模型回答重新加载成世界观事实。

上下文为4096 token，历史预算1100估算 token，自然生成上限192 token，原文选择上限48 token。闲聊通常不超过100字；事实摘录尽量选择较短完整单元，有后续纠正或不同记载时允许更长。启动时先加载并预热模型，默认保持常驻；本机8GB显存采用完整GPU推理，路由与对话保持同一上下文大小以免换载。可用 `FRISTON_CHAT_MODEL` 覆盖统一模型，`FRISTON_OLLAMA_KEEP_ALIVE` 覆盖驻留时间。

v2 对于语义高置信路径不再启动 Qwen 路由；仅不确定分支的 Qwen 路由默认最多等待 3 秒，同时受整轮 8 秒预算约束。默认 fallback=`semantic`：路由出错时不再自动检索无关剧情，而是清晰承认未判断准确；旧版 `retrieve` 仅作为显式兼容选择。高置信聊天需要一次自然生成；不代表不调用语言模型。网络超时与生成预算不构成包含数据库、操作系统排队在内的硬实时保证。

### Agentic v2 配置与手动验收

配置在 `NpcTalkSkill` 创建时读取；修改环境变量后退出并重新启动 `python main.py`。继续使用 `FRISTON_CHAT_MODEL` 指定的同一个常驻模型。

| 环境变量 | 默认值 | 用途 |
| --- | --- | --- |
| `FRISTON_AGENTIC_RAG` | `1` | `0` 关闭新路由，回到原检索流程 |
| `FRISTON_AGENTIC_FALLBACK` | `semantic` | Qwen 路由出错时，不确定请求明确短答而不是无依据检索；旧值 `retrieve` / `refuse` 可选（建议不使用 `retrieve`） |
| `FRISTON_AGENTIC_ROUTE_TIMEOUT` | `3` | 路由请求超时秒数，范围0.5—30 |
| `FRISTON_AGENTIC_TURN_TIMEOUT` | `8` | 整轮模型请求使用的剩余预算秒数，范围1—60 |
| `FRISTON_AGENTIC_REUSE_TURNS` | `3` | 证据最多供后续几轮复用，范围0—10；`0` 禁用复用 |
| `FRISTON_INTENT_ROUTER` | `1` | `0` 关闭 Embedding 意图层，保留 Qwen 上下文路由 |
| `FRISTON_INTENT_SIM_MIN` | `0.78` | 近邻最高余弦相似度下限（非概率），范围0—1 |
| `FRISTON_INTENT_MARGIN_MIN` | `0.045` | 领先类别与第二类别的 Top-3 平均相似度差下限 |
| `FRISTON_INTENT_AGREE_MIN` | `0.8` | Top-5 语义近邻中同类占比下限（0.8 表示至少4/5） |

证据缓存只存最终实际被引用的原文及出处；候选证据虽已发送但没有用于最终答案时，不得复用或当作依据（例如无关「吃饭」剧情不会因一次误检索而污染缓存）。不保存模型回答为知识。复用不续期；数据库文件/SQLite WAL/角色资料文件的时间戳或大小变化会使缓存失效。清空短期记忆也清缓存。主体指代独立保留在短期对话中，证据过期后仍可重新检索。文件元数据失效检查不代替内容哈希认证；重建知识库或修改角色资料后应重启进程。

在 PowerShell 中手动启动：

```powershell
conda activate photorobot
$env:FRISTON_AGENTIC_RAG = "1"
$env:FRISTON_AGENTIC_FALLBACK = "semantic"
python main.py
```

手动输入不同表达的日常问候（例如“忙了一天累不累”“吃了晚饭没”）、自我介绍、罗德岛人物事实、基于剧情的观点、追问、现实经费与复合问句（例如“你好，陈是谁”）。检查输出的 `semantic.label`、`semantic.candidate`、`agreement`、`margin` 以及 `decision / retrieval_calls / model_phases`。高置信闲聊应 `decision=CHAT, retrieval_calls=0, model_phases=["chat_generation"]`；已知的自我身份请求应使用原作证据；明确知识需求应进入 RETRIEVE；原文足够的追问才允许 REUSE。分类器不确定时调用 `agentic_route`；一旦超时，默认 `REFUSE`，**不是自动 RETRIEVE**。LIVE 的实时账本/现场观测请求无相应数据源时不猜测；混合问句含事实需求时不得被聊天部分掩盖。这些是手动验收目标，不是宣称已实测通过。

`[IntentRouter]` 在启动时打印语义索引状态；首次缓存 `data/runtime/intent_semantic.npz` 可多耗启动时间，但不需要重建 `terra_semantic.npz`。意图语料可以改写，重启会按文件 SHA-256 自动更新该小索引。`[AgenticRAG]` 输出语义近邻分数、最终决策、模型原始决策、回退原因、调用阶段与耗时；`retrieval_calls` 计数 `retrieve_packet` 入口调用，不代表内部搜索次数。输入“查看证据”还能查看路由实际输入、可选/选中/最终使用来源和缓存年龄。`REUSE` 后的 `retrieval` 元数据来自原证据包，本轮没有重新检索，以 `agentic_rag.retrieval_calls` 为准。未解决的称呼歧义走既有澄清路径；记忆命令和真实执行记录走 `BYPASS`。

临时关闭：退出程序后设置 `$env:FRISTON_AGENTIC_RAG = "0"` 并重启。该模式日志为 `LEGACY`，不调用 `agentic_route`。

本次 v2 仅进行源码静态审查与补丁核对；没有生成或运行自动测试，也没有连接本机 Ollama、相机或机械臂。路由的准确率、P95 与阈值尚未在用户运行环境中标定，需按上述步骤自行手动验收。进一步的原理、阈值和故障定位见 [语义路由 v2](docs/SEMANTIC_ROUTING_V2.md)。以下性能数字和旧 `docs/DIALOGUE_*` 均属于此前版本，不是 Agentic v2 的测量或验收结论。

2026-10-20 此前版本本机实测（RTX 4070 Laptop 8GB，完整文本返回时间，模型已预热）：

| 验证范围 | 中位数 | P95 | 最慢 | 超过5秒 |
| --- | --- | --- | --- | --- |
| 58组数据库场景、65轮问答与追问 | 0.67秒 | 1.66秒 | 2.58秒 | 0 |
| 16轮连续混合交互中的12轮对话，包含规划器耗时 | 0.75秒 | 2.73秒 | 2.73秒 | 0 |

65轮逐条对照材料复核：54轮实质回答、2轮明确限定的部分回答、5轮合理不确认、2轮歧义澄清、1轮用户自述记忆确认、1轮闲聊；未发现错人、关系方向颠倒或无依据拒答。这是修复后的回归结果，不是全世界观的准确率。随后连续交互修复了闲聊误检索、用途问法和单字人物漏识别，最后16轮重新验证；摄影使用替身，仅验证调度与参数边界。复杂事实摘录仍可能较长，这是保留原文限定的取舍。

实测冷加载和预热约9.93秒，发生在启动阶段；访客提问前应等待启动完成。修改代码后需退出已有进程，再运行 `python main.py`。连续验证期间路由与对话始终共用同一个9B模型，未反复换载。知识库文件哈希保持不变。

## 工程职责

| 路径 | 职责 |
| --- | --- |
| `main.py` / `preview.py` | Agent 命令行 / 视觉预览入口 |
| `friston2/config.py` | 项目绝对路径、模型和 Ollama 配置 |
| `friston2/agent.py` / `planner.py` | 指令调度 / LLM 技能选择 |
| `friston2/skills/` | 独立技能、参数验证与执行 |
| `friston2/knowledge/terra_kb.py` | 知识库构建、查询与 CLI 入口 |
| `friston2/knowledge/` | Wiki 导入、图谱存储、资料检索与证据整理 |
| `friston2/npc/` | Friston-3 人格、身份和直接关系边界与独立互动记忆 |
| `friston2/vision/` / `hardware/` | YuNet 与构图 / 真实摄像头适配器 |
| `data/knowledge/` | 有来源的 Friston-3 角色卡及构建记录 |
| `data/external/arknights_lore_wiki/` | 上游 Wiki 源文件 |
| `data/runtime/` | 生成知识库、真实互动记忆与子图导出 |
| `models/` / `photos/` | YuNet ONNX / 拍摄输出 |

`Agent → Planner → SkillManager → Skill → Hardware Adapter` 的边界保持不变。模型只能选择注册技能，参数仍由技能管理器验证，不能直接控制硬件。后续机械臂继续通过独立技能和硬件适配器接入。

历史测试工具仍在 `tests/`，本次没有为了对话优化扩充测试文件。摄影和硬件实现保持原有职责；连续交互验证使用禁止实际摄影的替身，不把路由检查算作真实拍摄成功。
