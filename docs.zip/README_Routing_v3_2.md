# Friston-3 v3.2：路由字段容错与原始输出诊断

适用基础：本次上传的 docs(10).zip，即已安装 v3.1 timeout fix 的版本。
这是增量补丁，仅包含两个业务代码文件和本说明，不是完整项目。

## 本次日志究竟说明什么

模型请求已经在 2.573 秒返回，实际 prompt 处理 0.421 秒、解码 1.953 秒、加载 0.005 秒。
failure_stage=validate_plan，error_kind=planning_error；本次故障发生在本地校验阶段。
原来的 8 秒超时配置不需要继续调大。

代码走到这个错误时，已通过 JSON 解析、字段集合、类型、route/intent 枚举和长度校验，
且已选 skill=npc_talk、arguments={}。

旧代码把以下情况合并成 router reply/query does not match its route：

- CHAT 没有提供非空 reply；
- 非 CHAT 路线多填了 reply；
- 非 RETRIEVE/REUSE 路线多填了 query。

当前日志没有保存模型返回的原始 JSON，因此不能证明本次具体属于哪一种，
也不能将输入中的 KNOWLEDGE 向量建议当作模型实际选择的 RETRIEVE。
retrieval_calls=0 表示校验失败后还没有进入检索，并不证明数据库或检索功能故障。

## 修改内容

覆盖的业务文件：

- friston3/npc/agentic_rag.py
- friston3/planner.py

parse_decision 继续严格检查字段、类型、枚举、长度及重复 JSON 键。
对于合法路线，清除不被该路线使用的字段：

| 路线 | 处理 |
| --- | --- |
| RETRIEVE / REUSE | 保留 query，清除多余 reply；仍走原有检索与基于资料的回答路径。 |
| CHAT | 要求非空 reply，清除多余 query；回复仍经过既有聊天检查。 |
| LIVE / CLARIFY | 清除多余 query 和 reply；仍使用原有能力说明或澄清回复。 |

这只是根据已选路线规范字段，不改变模型选中的 route、skill、intent、followup 或 detail。
丢弃的检索前草稿不作为回答或事实资料，也不进入对话历史。
RETRIEVE/REUSE 的空 query 仍由原有知识任务代码依据用户输入与上下文处理。
CHAT 缺少 reply 时会明确报出 router CHAT requires a non-empty reply；
本包不自动猜测另一条路线，也不增加一轮模型调用去补写回答。

Planner 在校验前保存 raw_output，解析后保存 parsed_plan。
成功通过 NPC 解析时额外保存 normalizations 和 normalized_decision。
这些字段进入现有“查看证据”的内存记录，没有新增落盘日志。
diagnostics 不混入六字段路由对象，因此不会破坏 NPC 接收计划时的二次解析。
独立 NPC 路由也会使用新的字段处理；本次新增的原始输出诊断位于统一 Planner 路径。

硬件动作仍使用原有独立严格校验；本次没有修改设备技能、数据库、模型配置、
语音、角色身份、超时设置、检索流程或回答生成流程，也没有添加依赖和测试文件。

## 安装

先在程序里输入“退出”，将本 ZIP 放到 C:\Users\FIRST\Desktop\Friston-3。
以下命令将两个原业务文件备份到项目旁边，随后覆盖补丁并启动：

```powershell
conda activate photorobot
Set-Location C:\Users\FIRST\Desktop\Friston-3

$fristonRoot = (Get-Location).Path
$fristonBackup = Join-Path (Split-Path $fristonRoot -Parent) ("Friston-3_before_v32_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
$fristonFiles = @("friston3\planner.py", "friston3\npc\agentic_rag.py")
foreach ($relative in $fristonFiles) {
    $destination = Join-Path $fristonBackup $relative
    New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force -ErrorAction Stop | Out-Null
    Copy-Item -LiteralPath (Join-Path $fristonRoot $relative) -Destination $destination -ErrorAction Stop
}
Write-Host "原文件备份位置：$fristonBackup"

Expand-Archive -LiteralPath .\Friston3_Routing_v3_2_contract_fix.zip -DestinationPath . -Force -ErrorAction Stop
$env:FRISTON_AGENTIC_ROUTE_TIMEOUT = "8"
python main.py
```

如需回退，在同一 PowerShell 窗口退出 main.py 后运行：

```powershell
foreach ($relative in $fristonFiles) {
    Copy-Item -LiteralPath (Join-Path $fristonBackup $relative) -Destination (Join-Path $fristonRoot $relative) -Force -ErrorAction Stop
}
python main.py
```

如果已关闭该窗口，先把 fristonBackup 设置为安装时显示的实际备份目录，并重新定义其余变量。

## 一次手动验收

输入原问题，再查看证据：

```text
认识可露希尔吗
查看证据
```

关注 ollama_calls 中 phase=unified_plan 的记录；成功的统一 NPC 规划记录也可见于
agentic_rag.planner_call，规划失败时可见于顶层 planner_call。

例如原始 route=RETRIEVE 且多填了 reply 时，应能看到：

```json
{
  "normalizations": ["discarded_unused_reply_for_RETRIEVE"],
  "normalized_decision": {
    "route": "RETRIEVE",
    "query": "可露希尔的身份与背景",
    "followup": false,
    "intent": "introduction",
    "detail": false,
    "reply": ""
  }
}
```

上面只是字段处理的示例，不是本次模型返回值，也不是对模型下次选择的预测。
若仍然失败，raw_output 和具体 error 将能区分空 CHAT 回复、其他格式错误或真正的超时。
网络未返回文本时不会出现 raw_output。

## 验证与适用边界

已做两个修改文件的 AST 解析、内存编译、源码差异检查和独立只读审查。
未执行项目、自动测试或用户机器上的 Ollama，也没有启动摄像头和串口。
只确认本次字段容错与证据记录的源码改动；未实测 Qwen3.5 9B 的新输出和端到端延迟。

本次 2.573 秒是规划阶段耗时。后续检索、回答生成、复核和语音另有开销，
不能据此宣称整轮 5 秒内完成。本包不增加模型调用，也不声称能纠正所有语义误路由。
如果原故障是 CHAT 缺少 reply，本包会明确暴露这个仍需处理的问题，而不会伪造成功。
