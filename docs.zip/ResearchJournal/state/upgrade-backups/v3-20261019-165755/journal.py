#!/usr/bin/env python3
"""Friston-2 ResearchJournal. Python standard library only; never touches source code.

Commands:
    python journal.py watch      # persistent background watcher
    python journal.py once       # process current state if it differs from baseline
    python journal.py status     # read-only status
    python journal.py import     # scan inbox only

No Git commit, no test execution, no writes outside ResearchJournal.
"""
from __future__ import annotations

import argparse
import datetime as dt
import difflib
import fnmatch
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback
import zipfile

HOME = Path(__file__).resolve().parent
PROJECT = HOME.parent
STATE = HOME / "state"
VAULT = HOME / "vault"
INBOX = HOME / "inbox"
VERSIONS = VAULT / "01-版本记录"
CARDS = VAULT / "02-技术卡片"
CHATS = VAULT / "03-GPT对话"
BASELINE = STATE / "baseline.json.gz"
CHAT_INDEX = STATE / "chat-index.json"
IMPORTED = STATE / "imported-archives.json"
RETRY = STATE / "retry"
LOG = STATE / "agent.log"
BASE_CONFIG = HOME / "config.json"
SECRET_RE = re.compile(
    r"(?i)((?:[\"']?)(?:api[_-]?key|access[_-]?token|client[_-]?secret|password|passwd|private[_-]?key|authorization)(?:[\"']?)\s*[=:]\s*)([\"']?[^\s,;}\"']+[\"']?)"
)
LINK_RE = re.compile(r"[^\w\u4e00-\u9fff\- ]+", flags=re.UNICODE)


def now_local():
    return dt.datetime.now().astimezone()


def time_text():
    return now_local().strftime("%Y-%m-%d %H:%M:%S %z")


def log(msg):
    STATE.mkdir(parents=True, exist_ok=True)
    try:
        if LOG.exists() and LOG.stat().st_size > 2_000_000:
            LOG.replace(STATE / "agent.log.previous")
        with LOG.open("a", encoding="utf-8") as f:
            f.write(f"[{time_text()}] {msg}\n")
    except OSError:
        pass


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def save_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp, path)


def load_config():
    return load_json(BASE_CONFIG, {})


def sha(text):
    if isinstance(text, str):
        text = text.encode("utf-8")
    return hashlib.sha256(text).hexdigest()


def make_dirs():
    for p in (STATE, INBOX, VAULT, VERSIONS, CARDS, CHATS, RETRY):
        p.mkdir(parents=True, exist_ok=True)


def scan(config):
    """Only read code and selected plaintext files. Never inspect external data folders."""
    excludes = {x.casefold() for x in config.get("excluded_dirs", [])}
    extensions = {x.lower() for x in config.get("source_extensions", [])}
    patterns = [p.lower() for p in config.get("excluded_name_patterns", [])]
    limit = int(config.get("max_file_bytes", 262144))
    files = {}
    for folder, dirs, names in os.walk(PROJECT, topdown=True, followlinks=False):
        dirs[:] = [d for d in dirs if d.casefold() not in excludes
                   and not (Path(folder) / d).is_symlink()]
        for name in names:
            path = Path(folder) / name
            if path.is_symlink() or path.suffix.lower() not in extensions:
                continue
            if any(fnmatch.fnmatch(name.lower(), p) for p in patterns):
                continue
            try:
                if path.stat().st_size > limit:
                    continue
                content = path.read_bytes()
                if b"\x00" in content or len(content) > limit:
                    continue
                text = content.decode("utf-8-sig")
                rel = path.relative_to(PROJECT).as_posix()
                files[rel] = text
            except (OSError, UnicodeError):
                continue
    return files


def signature(files):
    acc = hashlib.sha256()
    for name, body in sorted(files.items()):
        acc.update(name.encode("utf-8"))
        acc.update(b"\x00")
        acc.update(sha(body).encode("ascii"))
    return acc.hexdigest()


def save_baseline(files, content_sig):
    record = {"signature": content_sig, "updated": time_text(), "files": files}
    tmp = BASELINE.with_name(BASELINE.name + ".tmp")
    with gzip.open(tmp, "wt", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False)
    os.replace(tmp, BASELINE)


def read_baseline():
    try:
        with gzip.open(BASELINE, "rt", encoding="utf-8") as f:
            old = json.load(f)
        if isinstance(old.get("files"), dict):
            return old
    except (OSError, ValueError, TypeError):
        pass
    return None


def changed_files(old, new):
    names = sorted(set(old) | set(new))
    return [name for name in names if old.get(name) != new.get(name)]


def redact(s):
    # Best-effort only. Exclusion filters, not this regex, are the security boundary.
    s = SECRET_RE.sub(lambda m: m.group(1) + "[REDACTED]", s)
    s = re.sub(r"sk-[a-zA-Z0-9_-]{16,}", "[REDACTED-TOKEN]", s)
    return s


def diff_text(old, new, changed, max_chars):
    parts = []
    summary = []
    for rel in changed:
        before = old.get(rel, "").splitlines(keepends=True)
        after = new.get(rel, "").splitlines(keepends=True)
        kind = "修改" if rel in old and rel in new else ("新增" if rel in new else "删除")
        delta = list(difflib.unified_diff(before, after,
                                          fromfile="previous/" + rel,
                                          tofile="current/" + rel, n=3))
        adds = sum(1 for l in delta if l.startswith("+") and not l.startswith("+++"))
        subs = sum(1 for l in delta if l.startswith("-") and not l.startswith("---"))
        summary.append({"path": rel, "action": kind, "added": adds, "removed": subs})
        parts.append("".join(delta))
    combined = redact("\n".join(parts))
    if len(combined) > max_chars:
        combined = combined[:max_chars] + "\n\n[差异过长已截断；请根据路径只读检查源代码]\n"
    return combined, summary


def safe_name(title, limit=66):
    title = LINK_RE.sub("", str(title)).strip(" .-_")
    return (title or "未命名")[:limit]


def render_export_part(part):
    if isinstance(part, str):
        return part
    if isinstance(part, dict):
        if isinstance(part.get("text"), str):
            return part["text"]
        if isinstance(part.get("content"), str):
            return part["content"]
    return ""


def messages_from_export(conv):
    mapping = conv.get("mapping", {})
    output = []
    active_branch = False
    if isinstance(mapping, dict):
        current = conv.get("current_node")
        branch = []
        seen = set()
        # ChatGPT exports may contain hidden alternative responses.
        # Follow current_node -> parent to represent the visible branch only.
        while current and current in mapping and current not in seen:
            seen.add(current)
            node = mapping[current]
            branch.append(node)
            current = node.get("parent") if isinstance(node, dict) else None
        if branch:
            branch.reverse()
            nodes = branch
            active_branch = True
        else:
            nodes = list(mapping.values())
        for node in nodes:
            msg = node.get("message") if isinstance(node, dict) else None
            if not isinstance(msg, dict):
                continue
            role = ((msg.get("author") or {}).get("role") or "").lower()
            if role not in ("user", "assistant"):
                continue
            content = msg.get("content") or {}
            parts = content.get("parts") or [] if isinstance(content, dict) else []
            if isinstance(parts, str):
                parts = [parts]
            body = "\n".join(render_export_part(x) for x in parts)
            body = body.strip()
            if not body and isinstance(content, dict):
                body = str(content.get("text") or "").strip()
            if body:
                output.append((float(msg.get("create_time") or 0), role, body))
    elif isinstance(conv.get("messages"), list):
        for i, msg in enumerate(conv["messages"]):
            role = str(msg.get("role", "")).lower()
            body = msg.get("content", "")
            if role in ("user", "assistant") and isinstance(body, str):
                output.append((float(msg.get("create_time") or i), role, body))
    return output if active_branch else sorted(output, key=lambda item: item[0])


def looks_relevant(title, msgs, config):
    words = [w.casefold() for w in config.get("chat_keywords", [])]
    title_lo = title.casefold()
    subset = msgs[:40] + msgs[-40:] if len(msgs) > 80 else msgs
    blob = (title + "\n" + "\n".join(body[:800] for _, _, body in subset))[:45000].casefold()
    key_terms = ("friston-2", "photorobot", "cosrobot", "photobot", "罗德岛工程部")
    if any(k in blob for k in key_terms):
        return True
    # Relevant without project name only when multiple robotics-specific concepts appear.
    return sum(w in blob for w in words if w not in ("rag", "act")) >= 2 and (
        "机器人" in blob or "机械臂" in blob or "agent" in blob or "lerobot" in blob
    )


def export_records(raw, config):
    if isinstance(raw, dict):
        raw = raw.get("conversations", [])
    if not isinstance(raw, list):
        return []
    results = []
    for conv in raw:
        if not isinstance(conv, dict):
            continue
        title = str(conv.get("title") or "未命名对话")
        msgs = messages_from_export(conv)
        if not msgs or not looks_relevant(title, msgs, config):
            continue
        cid = str(conv.get("id") or sha(title + str(len(msgs))))
        header = (f"# {title}\n\n来源：ChatGPT 数据导出；只用于理解历史技术讨论，"
                  "并不能证明代码已经实现。\n\n")
        chunks, size = [], 0
        for _, role, body in msgs[-100:]:
            body = redact(body.strip())[:1800]
            block = f"## {'用户' if role == 'user' else '助手'}\n\n{body}\n\n"
            if size + len(block) > 45000:
                break
            chunks.append(block)
            size += len(block)
        document = header + "".join(chunks)
        if len(document) <= len(header):
            continue
        fname = safe_name(title, 50) + "-" + sha(cid)[:8] + ".md"
        results.append({"id": cid, "title": title, "file": fname,
                        "preview": " ".join(body[:250] for _, _, body in msgs[-8:])[:2000],
                        "document": document})
    return results


def import_inbox(config):
    """Only explicitly placed exports and Markdown are imported; no website scraping."""
    seen = load_json(IMPORTED, {})
    index = load_json(CHAT_INDEX, [])
    by_id = {entry["id"]: entry for entry in index if isinstance(entry, dict) and "id" in entry}
    modified = False
    for p in sorted(INBOX.iterdir()):
        if not p.is_file() or p.suffix.lower() not in (".zip", ".json", ".md", ".txt"):
            continue
        stamp = f"{p.stat().st_size}:{p.stat().st_mtime_ns}"
        if seen.get(p.name) == stamp:
            continue
        records = []
        try:
            if p.suffix.lower() == ".zip":
                with zipfile.ZipFile(p) as z:
                    members = [x for x in z.infolist()
                               if re.search(r"(?:^|/)(?:conversations(?:[_-]\d+)?|conversation_\d+)\.json$", x.filename, re.I)
                               and x.file_size < 130_000_000]
                    for item in members[:20]:
                        records.extend(export_records(json.loads(z.read(item).decode("utf-8-sig")), config))
            elif p.suffix.lower() == ".json":
                if p.stat().st_size < 130_000_000:
                    records.extend(export_records(json.loads(p.read_text(encoding="utf-8-sig")), config))
            else:
                # Treat explicitly supplied .md/.txt as GPT discussion context.
                body = redact(p.read_text(encoding="utf-8"))[:45000]
                if body.strip():
                    cid = "inbox-" + sha(p.name)[:16]
                    records.append({"id": cid, "title": p.stem,
                                    "file": safe_name(p.stem) + "-" + sha(cid)[:8] + ".md",
                                    "preview": body[:2000], "document": "# " + p.stem + "\n\n" + body})
            for item in records[:200]:
                (CHATS / item["file"]).write_text(item["document"], encoding="utf-8")
                by_id[item["id"]] = {k: item[k] for k in ("id", "title", "file", "preview")}
            seen[p.name] = stamp
            modified = True
            log(f"GPT import {p.name}: {len(records)} relevant conversations")
        except (OSError, ValueError, UnicodeError, zipfile.BadZipFile) as exc:
            log(f"GPT import failed {p.name}: {exc}")
    if modified:
        save_json(IMPORTED, seen)
        save_json(CHAT_INDEX, list(by_id.values()))
    return len(by_id)


def relevant_chats(changed, config):
    index = load_json(CHAT_INDEX, [])
    if not index:
        return [], ""
    terms = {Path(f).stem.lower() for f in changed}
    name_blob = " ".join(changed).lower()
    groups = {
        "rag": ["知识库", "检索", "embedding", "rerank", "sqlite", "llm", "npc", "rag"],
        "knowledge": ["知识库", "检索", "r a g", "rag", "npc"],
        "terra": ["明日方舟", "人物关系", "npc", "知识库"],
        "photo": ["摄影", "拍照", "构图", "相机", "vision"],
        "camera": ["相机", "检测", "摄影", "拍照"],
        "arm": ["机械臂", "so-101", "lerobot", "act"],
        "agent": ["agent", "skill", "planner", "工具调用"],
    }
    hints = []
    for key, words in groups.items():
        if key in name_blob:
            hints += words
    hints += [x for x in terms if len(x) > 3]
    ranked = []
    for entry in index:
        haystack = (entry.get("title", "") + " " + entry.get("preview", "")).casefold()
        score = sum(3 if term in entry.get("title", "").casefold() else 1
                    for term in hints if term.casefold() in haystack)
        if score > 0:
            ranked.append((score, entry))
    ranked.sort(key=lambda x: x[0], reverse=True)
    picks = [entry for _, entry in ranked[:4]]
    context = []
    cap = int(config.get("max_context_characters", 14000))
    remaining = cap
    for item in picks:
        body = (CHATS / item["file"]).read_text(encoding="utf-8")
        clipped = body[:min(3500, remaining)]
        context.append("对话文档：[[03-GPT对话/" + item["file"][:-3] + "]]\n" + clipped)
        remaining -= len(clipped)
        if remaining <= 0:
            break
    return picks, "\n\n---\n\n".join(context)


def make_prompt(old_sig, new_sig, diff, stats, picked, chat_text):
    skill = (HOME / "skills" / "friston-research-journal" / "SKILL.md").read_text(encoding="utf-8")
    decisions = (HOME / "context" / "project-decisions.md").read_text(encoding="utf-8")
    links = (HOME / "context" / "official-links.md").read_text(encoding="utf-8")
    recorded_chats = "\n".join(f"- [[03-GPT对话/{c['file'][:-3]}]]" for c in picked)
    return f"""请分析下面的 Friston-2 增量开发变更，**不要执行代码、不要编写或运行测试，不要修改任何项目文件**。

{skill}

本次旧快照 SHA256={old_sig}；新快照 SHA256={new_sig}

【客观文件修改统计】
{json.dumps(stats, ensure_ascii=False, indent=2)}

【源代码 unified diff（已经初步脱敏，可能截断）】
```diff
{diff}
```

【此前 GPT 对话中的项目决策摘要：是背景，不是功能验收证据】
{decisions}

【ChatGPT 导出聊天与本次变更的相关历史讨论（可能为空、较旧）】
{chat_text or '无已导入的匹配聊天记录。'}

【可在笔记中引用的会话链接】
{recorded_chats or '无'}

【预置官方资料链接】
{links}

要求 JSON 输出：title 是 8～30 字的版本标题；markdown 是中文 Obsidian 版本日志正文；concepts 0～3 项，仅当本次确实涉及重要算法技术。
markdown 至少有：问题/动机、Baseline、改了什么（含路径和关键函数/类）、新技术简介与取舍、Baseline 结果表（实测无证据则未测量）、GPT 历史决策核对、潜在问题、手动验收清单、面试追问、可用于简历的审慎描述、官方资源。
每个数值要有来源；不能将拟实施的 Hybrid RAG/GraphRAG/ACT 等写为已完成。不要声称已运行任何验证。"""


def output_schema():
    return {"type": "object", "additionalProperties": False,
            "required": ["title", "markdown", "concepts"],
            "properties": {
                "title": {"type": "string"},
                "markdown": {"type": "string"},
                "concepts": {"type": "array", "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["name", "markdown"],
                    "properties": {"name": {"type": "string"}, "markdown": {"type": "string"}}
                }}
            }}


def codex_analyze(prompt, new_sig, config):
    codex = shutil.which("codex") or shutil.which("codex.cmd")
    if not codex:
        raise RuntimeError("找不到 codex CLI；请安装并登录 Codex，或等待自动重试。")
    schema_file = STATE / "report-schema.json"
    answer_file = STATE / f"answer-{new_sig[:12]}.json"
    save_json(schema_file, output_schema())
    cmd = [codex, "exec", "--cd", str(HOME), "--sandbox", "read-only",
           "--skip-git-repo-check", "--ephemeral", "--output-schema", str(schema_file),
           "--output-last-message", str(answer_file), "-"]
    try:
        proc = subprocess.run(cmd, input=prompt, text=True, encoding="utf-8",
                              errors="replace", capture_output=True,
                              cwd=str(HOME), timeout=int(config.get("codex_timeout_seconds", 420)))
    except subprocess.TimeoutExpired as e:
        raise RuntimeError("Codex 超时（下次后台自动重试）") from e
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()[-1200:]
        raise RuntimeError("Codex 失败：" + detail)
    if not answer_file.exists():
        raise RuntimeError("Codex 未返回有效输出文件")
    result = load_json(answer_file, {})
    if not isinstance(result, dict) or not isinstance(result.get("markdown"), str) or not result["markdown"].strip():
        raise RuntimeError("Codex 返回的内容不符合 JSON 结构")
    try:
        answer_file.unlink()
    except OSError:
        pass
    return result


def initial_report(diff, stats, error):
    lines = "\n".join(f"- {s['action']} `{s['path']}`：+{s['added']} / -{s['removed']}" for s in stats)
    return {"title": "自动快照（AI 待补充）", "concepts": [],
            "markdown": f"""## 本轮客观修改\n\n{lines}\n\n## 说明\n\nAI 解释暂不可用，后台会尝试补全此条目。原因：{redact(str(error))[:350]}\n\n## Baseline / 技术分析 / 面试素材\n\n待自动补全，**不得用未验证的改进数值填空**。本轮未执行任何项目测试。\n"""}


def write_note(result, new_sig, old_sig, stats, picked, pending=False, path=None):
    stamp = now_local().strftime("%Y-%m-%d_%H%M%S")
    path = path or (VERSIONS / f"{stamp}-{new_sig[:10]}.md")
    tag = "待AI补全" if pending else "已生成待人工核对"
    chatrefs = "\n".join(f"- [[03-GPT对话/{c['file'][:-3]}]]" for c in picked)
    front = (f"---\ntype: research-log\ncreated: {now_local().strftime('%Y-%m-%d')}\n"
             f"status: '{tag}'\nsource_before: '{old_sig[:16]}'\nsource_after: '{new_sig[:16]}'\n"
             f"---\n\n# {result.get('title', 'Friston-2 研发记录')}\n\n"
             "**来源等级**：文件差异 = 客观证据；GPT 对话 = 当时讨论；推测/指标 = 必须注明未验证。\n\n")
    appendix = "\n\n---\n\n## 代码变更清单（自动统计）\n\n"
    appendix += "\n".join(f"- `{s['path']}`：{s['action']}（+{s['added']} / -{s['removed']} 行）" for s in stats)
    appendix += "\n\n## 本轮参考的 GPT 对话\n\n" + (chatrefs or "仅参考内置项目决策摘要；无自动同步的 GPT 历史记录。")
    content = front + result["markdown"].strip() + appendix + "\n"
    path.write_text(content, encoding="utf-8")
    return path


def append_cards(result, note_path):
    for item in (result.get("concepts") or [])[:3]:
        name = safe_name(item.get("name", ""), 58)
        content = item.get("markdown", "").strip()
        if not name or not content:
            continue
        dest = CARDS / (name + ".md")
        ref = f"[[01-版本记录/{note_path.stem}]]"
        if not dest.exists():
            dest.write_text(f"# {name}\n\n", encoding="utf-8")
        existing = dest.read_text(encoding="utf-8")
        if ref in existing:
            continue
        with dest.open("a", encoding="utf-8") as f:
            f.write(f"\n## {now_local().strftime('%Y-%m-%d')} · {ref}\n\n{content}\n")


def update_index():
    entries = sorted(VERSIONS.glob("*.md"), reverse=True)
    body = "# Friston-2 研发知识库\n\n"
    body += "本仓库记录依据：自动比较源码快照；ChatGPT 讨论可作为动机，但不能证明已经实现或验证。\n\n"
    body += "## 版本时间线\n\n"
    for p in entries[:300]:
        title = p.stem
        try:
            line = next((x for x in p.read_text(encoding="utf-8").splitlines() if x.startswith("# ")), None)
            if line:
                title = line[2:]
        except OSError:
            pass
        body += f"- [[01-版本记录/{p.stem}|{p.stem[:16]} · {title}]]\n"
    if not entries:
        body += "等待首次代码改动稳定后自动生成。\n"
    body += "\n## 分类入口\n\n- [[02-技术卡片]]（技术学习卡）\n- [[03-GPT对话]]（导入的历史对话）\n"
    (VAULT / "00-研发总览.md").write_text(body, encoding="utf-8")


def produce(old, files, config):
    old_files = old["files"]
    before = old["signature"]
    after = signature(files)
    changes = changed_files(old_files, files)
    if not changes:
        return False
    diff, stats = diff_text(old_files, files, changes, int(config.get("max_diff_characters", 90000)))
    selected, chat_text = relevant_chats(changes, config)
    prompt = make_prompt(before, after, diff, stats, selected, chat_text)
    retry_file = RETRY / f"{after[:16]}.json"
    # Save only the prompt needed for eventual enrichment, keeping it local/private.
    payload = {"prompt": prompt, "after": after, "before": before,
               "stats": stats, "chats": selected, "created": time_text()}
    save_json(retry_file, payload)
    try:
        result = codex_analyze(prompt, after, config)
        pending = False
    except Exception as exc:
        result = initial_report(diff, stats, exc)
        pending = True
        payload["error"] = str(exc)[:600]
        payload["retry_after"] = time.time() + int(config.get("retry_failed_after_seconds", 1800))
        log(f"AI not available, preserving report for retry: {exc}")
    note = write_note(result, after, before, stats, selected, pending)
    if pending:
        payload["note_path"] = str(note)
        payload["fallback_hash"] = sha(note.read_text(encoding="utf-8"))
        save_json(retry_file, payload)
    else:
        retry_file.unlink(missing_ok=True)
        append_cards(result, note)
    update_index()
    # This checkpoint is independent of Git. No source modifications or commits.
    save_baseline(files, after)
    log(f"Snapshot {after[:12]}: {len(stats)} file(s); note {note.name}, pending={pending}")
    return True


def retry_once(config):
    for file in sorted(RETRY.glob("*.json")):
        item = load_json(file, {})
        if not item or time.time() < float(item.get("retry_after", 0)):
            continue
        note_path = Path(item.get("note_path", ""))
        if not note_path.is_file() or note_path.parent != VERSIONS:
            file.unlink(missing_ok=True)
            continue
        try:
            result = codex_analyze(item["prompt"], item["after"], config)
            # Preserve any edits the user made to the fallback note.
            if item.get("fallback_hash") and sha(note_path.read_text(encoding="utf-8")) != item["fallback_hash"]:
                with note_path.open("a", encoding="utf-8") as f:
                    f.write("\n\n---\n\n## AI 自动补充（保留上方人工编辑）\n\n" + result["markdown"].strip() + "\n")
            else:
                write_note(result, item["after"], item["before"], item["stats"],
                           item.get("chats", []), path=note_path)
            append_cards(result, note_path)
            file.unlink(missing_ok=True)
            update_index()
            log(f"AI enrichment finished: {note_path.name}")
        except Exception as exc:
            item["retry_after"] = time.time() + int(config.get("retry_failed_after_seconds", 1800))
            item["error"] = str(exc)[:600]
            save_json(file, item)
            log(f"AI enrichment postponed: {exc}")
        break  # avoid repeatedly calling the model for many records in one loop


def single_instance():
    """Prevent multiple daemon instances, Windows and POSIX without dependencies."""
    lock = (STATE / "watch.lock").open("a+b")
    lock.seek(0, 2)
    if lock.tell() == 0:
        lock.write(b"0")
        lock.flush()
    try:
        if os.name == "nt":
            import msvcrt
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return lock
    except OSError:
        lock.close()
        return None


def watch(config):
    guard = single_instance()
    if guard is None:
        log("Another watcher is already running; exiting")
        return 0
    (STATE / "watch.pid").write_text(str(os.getpid()), encoding="ascii")
    log(f"Watcher started on {PROJECT}")
    last_observed = None
    last_change = time.monotonic()
    last_report = 0.0
    next_retry = 0.0
    try:
        while True:
            try:
                import_inbox(config)
                current = scan(config)
                current_sig = signature(current)
                old = read_baseline()
                if old is None:
                    save_baseline(current, current_sig)
                    update_index()
                    log(f"Initial baseline established: {current_sig[:12]}, {len(current)} source files")
                else:
                    if current_sig != last_observed:
                        last_observed = current_sig
                        last_change = time.monotonic()
                    changed = current_sig != old["signature"]
                    ready = time.monotonic() - last_change >= int(config.get("quiet_seconds", 300))
                    cooled = time.monotonic() - last_report >= int(config.get("minimum_interval_seconds", 1200))
                    if changed and ready and cooled:
                        if produce(old, current, config):
                            last_report = time.monotonic()
                if time.monotonic() >= next_retry:
                    retry_once(config)
                    next_retry = time.monotonic() + 60
            except Exception as exc:
                log("Watcher cycle failed: " + repr(exc) + "\n" + traceback.format_exc()[-2400:])
            time.sleep(max(10, int(config.get("watch_interval_seconds", 30))))
    finally:
        try:
            (STATE / "watch.pid").unlink(missing_ok=True)
        except OSError:
            pass
        guard.close()


def main():
    parser = argparse.ArgumentParser(description="Friston-2 自动研发日志 Agent")
    parser.add_argument("command", choices=["watch", "once", "status", "import"])
    args = parser.parse_args()
    make_dirs()
    cfg = load_config()
    if args.command == "watch":
        return watch(cfg)
    if args.command == "import":
        print("已索引的项目相关 GPT 对话：", import_inbox(cfg))
        return 0
    current = scan(cfg)
    old = read_baseline()
    if args.command == "status":
        print("Project:", PROJECT)
        print("Journal:", HOME)
        print("Tracked source files:", len(current))
        print("Initial baseline exists:", bool(old))
        print("Changed files vs baseline:", len(changed_files(old["files"], current)) if old else "尚无初始基线")
        print("GPT imported chats:", len(load_json(CHAT_INDEX, [])))
        print("Pending AI reports:", len(list(RETRY.glob("*.json"))))
        print("Version notes:", len(list(VERSIONS.glob("*.md"))))
        return 0
    # once: optional manual recovery/debug, no prior Git stage required.
    import_inbox(cfg)
    if old is None:
        save_baseline(current, signature(current))
        update_index()
        print("已建立首次本地基线。之后会自动记录新改动。")
    else:
        print("已生成新版本记录。" if produce(old, current, cfg) else "源代码无变化，不生成重复记录。")
    retry_once(cfg)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        log("Watcher stopped by user")
