# Friston-3 · Agentic RAG v2 · 语义证据需求路由

## 为什么不继续追加关键词

`Agent` 的轻量路由只决定要不要额外询问**设备技能** Planner，并不会自动跳过 NPC 内的知识检索。`NpcTalkSkill` 里的 `conversation_act()` 是表达风格线索，不是判定事实证据需求的无限白名单。

「吃了吗」那轮发生的是 Qwen 路由请求在三秒后超时，旧版把所有路由错误统一回退为 RETRIEVE，才把毫无关系的吃饭故事送给原文选择器。分类问题与超时策略是两个需要分开解决的问题。

## 新的结构

1. **可信执行边界先行**：记忆命令、真实设备执行记录继续走原通路；角色自身身份和能力问答仍要求可靠设定来源；尚未接入的实际财务数据不允许用游戏剧情代替。
2. **语义证据需求分类器**（`friston2/npc/intent_router.py`）：对独立的 301 条标注对话示例做 FastEmbed Embedding，采用类别 Top-3 近邻得分、Top-5 类别一致度和类别间隔。类别是 CHAT、KNOWLEDGE、LIVE、FOLLOWUP。该指标不是经过校准的后验概率，需结合人工误判日志调阈值。
3. **高置信快捷路径**：CHAT 使用 `NPC_CHAT_PROMPT` 生成一次自然回复而非路由 JSON；KNOWLEDGE 直接进入现有知识检索；LIVE 无实时来源时诚实说明；FOLLOWUP 或 UNCERTAIN 进入原 Qwen 上下文路由。
4. **深度路由**：Qwen 继续负责根据历史和已经发送的证据决定 CHAT / REUSE / RETRIEVE、补全省略主语和检查复用是否仍有效。来源只允许选择当前明确提供的 S 编号。
5. **默认安全回退**：LLM 超时、JSON 错误、无效证据复用时，使用 `REFUSE` 而不是把失败自动解释成「需要检索」。`FRISTON_AGENTIC_FALLBACK=retrieve` 仅为兼容旧版保留，默认不要开启。CHAT 回复未通过本地角色/身份检查时，回复不带未经证实的事实；不会拿草稿去做检索。
6. **证据缓存隔离**：只有最终答案真正使用、并通过检查的证据 ID 才能进入 REUSE 缓存；检索候选、失败模型草稿、用户自述和模型历史台词都不能成为新世界观依据。

## 数据、性能和可维护性

- `data/knowledge/intent_examples.json`：独立的带标注意图样本。为了覆盖话语功能，包含同义表达、口语、省略、事实提问、实时问题与带闲聊前缀的事实混合问句；它不是 FAQ 命中表。
- `data/runtime/intent_semantic.npz`：轻量索引的自动持久化缓存；根据样本文件与所用 Embedding 模型指纹作废并重建；不是原作知识库索引。
- 使用原有 `BAAI/bge-small-zh-v1.5` FastEmbed `_encoder()`，不常驻新的 LLM，也不需要重新构建 `terra_lore.db`。首次启动生成 301 条 Embedding 要比后续读取缓存慢。未安装 FastEmbed / 模型不可用时仍可使用旧 Qwen 路由，但不会伪称分类成功。
- `FRISTON_INTENT_ROUTER=0` 仅关闭意图分类器。`FRISTON_AGENTIC_RAG=0` 关闭整个 Agentic 模式回到旧检索流程。
- 三个 `FRISTON_INTENT_*` 阈值均可在 PowerShell 里配置（详细看 README）。数值来自保守设计起点，**尚未通过人工保留样本校准**；不要将日志里打印的相似度解释成正确概率。

## 手动验收清单（不生成或运行自动测试）

进入项目根目录，`conda activate photorobot`，设置 `$env:FRISTON_AGENTIC_RAG="1"` 和 `$env:FRISTON_AGENTIC_FALLBACK="semantic"`，然后 `python main.py`。先观察 `[IntentRouter]` 的启动消息。

- 不同口语问候与关心（包括不在意图样本中的新句式）：目标 `CHAT`、`retrieval_calls=0`，`chat_generation` 通常只调用一次 Qwen。
- 「介绍一下自己」「说说你的历史」：目标检索角色自我档案，而非仅回答「我是 Friston」。
- 明确的人物身份、事件因果、关系问题：目标 `RETRIEVE`，不能只有闲聊回答。
- 实时资金、现场信息：无真实数据源时明确说不知道，不查游戏背景冒充实时证据。
- 角色事实后「那她后来怎么样」「为什么」：目标在有原文时 REUSE 或按需 RETRIEVE，缺乏先前主体时先澄清。
- 「你好，陈是谁」等混合请求：寒暄不能遮盖事实子请求。
- 每类检查一次「查看证据」：`agentic_rag.semantic` 字段报告近邻情况；`model_decision` 仅在运行 Qwen 路由时有值；`cache_source_ids` 只能包含最终引用的事实来源。
- 确认实际性能：记录 `elapsed_s`、`model_phases`、`retrieval_calls`，在人工标注的多样化问句上估计闲聊误检率、事实漏检率、P95。不能以几条示例就声称已校准。

这是架构修改，不是已经在你的 Windows / GPU / Ollama 环境进行的动态验收。建议先保持严格阈值：遇到语义不确定宁可走上下文模型，也不要贸然将世界观事实分到普通 CHAT。
